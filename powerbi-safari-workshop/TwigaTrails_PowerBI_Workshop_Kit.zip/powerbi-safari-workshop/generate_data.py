"""
Twiga Trails Safaris — Power BI workshop dataset generator.

Produces a deliberately *imperfect* dataset for a fictional East African
safari operator, plus an answer key computed from the cleaned data so a
facilitator can check every participant's numbers.

    python3 generate_data.py          # writes ./data and ./answer_key.json

Deterministic: the same seed always produces the same files.
"""

import json
import random
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Font

SEED = 20260915
random.seed(SEED)

ROOT = Path(__file__).parent
DATA = ROOT / "data"
(DATA / "Bookings").mkdir(parents=True, exist_ok=True)
(DATA / "_later").mkdir(parents=True, exist_ok=True)

EXTRACT_DATE = date(2026, 6, 30)  # "today" inside the dataset
MAIN_END = date(2025, 12, 31)     # files handed out at the start


def write_csv(path, header, rows):
    import csv
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


# --------------------------------------------------------------------------
# Dimensions
# --------------------------------------------------------------------------
PARKS = [
    # ParkID, ParkName, Country, Lat, Lon, Ecosystem, ParkFeeUSDPerDay
    ("P01", "Maasai Mara National Reserve", "Kenya", -1.4061, 35.0100, "Savanna", 100),
    ("P02", "Amboseli National Park", "Kenya", -2.6527, 37.2606, "Swamp & Savanna", 70),
    ("P03", "Tsavo East National Park", "Kenya", -2.7667, 38.7500, "Semi-arid Bush", 52),
    ("P04", "Samburu National Reserve", "Kenya", 0.6200, 37.5300, "Arid Riverine", 70),
    ("P05", "Lake Nakuru National Park", "Kenya", -0.3667, 36.0833, "Rift Valley Lake", 60),
    ("P06", "Serengeti National Park", "Tanzania", -2.3333, 34.8333, "Savanna", 83),
    ("P07", "Ngorongoro Conservation Area", "Tanzania", -3.2000, 35.5000, "Volcanic Crater", 71),
    ("P08", "Tarangire National Park", "Tanzania", -4.1667, 36.1000, "Baobab Woodland", 59),
    ("P09", "Bwindi Impenetrable National Park", "Uganda", -1.0500, 29.7000, "Montane Rainforest", 40),
    ("P10", "Volcanoes National Park", "Rwanda", -1.4833, 29.5333, "Montane Bamboo", 100),
]

PACKAGES = [
    # ID, Name, Category, Days, ParkID, BasePriceUSD (per adult), CostPerPaxUSD, LaunchDate, weight
    ("PK01", "Mara Express Camping", "Budget", 3, "P01", 420, 250, "2019-01-01", 10),
    ("PK02", "Nakuru & Naivasha Budget Trail", "Budget", 3, "P05", 380, 225, "2019-01-01", 7),
    ("PK03", "Amboseli Kilimanjaro Views Camping", "Budget", 4, "P02", 540, 320, "2020-03-01", 7),
    ("PK04", "Tsavo Red Elephants Road Trip", "Budget", 4, "P03", 500, 300, "2021-06-01", 5),
    ("PK05", "Northern Tanzania Group Camping", "Budget", 5, "P08", 780, 480, "2020-01-01", 5),
    ("PK06", "Classic Maasai Mara Lodge Safari", "Mid-Range", 4, "P01", 1250, 740, "2018-01-01", 12),
    ("PK07", "Kenya Big Five Circuit", "Mid-Range", 7, "P02", 2350, 1400, "2018-01-01", 8),
    ("PK08", "Samburu Special Five", "Mid-Range", 4, "P04", 1180, 700, "2019-05-01", 5),
    ("PK09", "Serengeti & Ngorongoro Explorer", "Mid-Range", 6, "P06", 2600, 1590, "2018-01-01", 8),
    ("PK10", "Tarangire Elephant Trails", "Mid-Range", 3, "P08", 890, 540, "2020-07-01", 5),
    ("PK11", "Kenya–Tanzania Cross-Border", "Mid-Range", 10, "P06", 3900, 2400, "2021-01-01", 4),
    ("PK12", "Mara Great Migration Luxury Camp", "Luxury", 5, "P01", 4800, 2750, "2018-01-01", 5),
    ("PK13", "Serengeti Migration Fly-In", "Luxury", 6, "P06", 6200, 3600, "2019-01-01", 4),
    ("PK14", "Ngorongoro Crater Lodge Escape", "Luxury", 4, "P07", 4100, 2400, "2020-01-01", 3),
    ("PK15", "Bwindi Gorilla Trek Premium", "Luxury", 4, "P09", 3900, 2500, "2019-01-01", 3),
    ("PK16", "Rwanda Gorillas & Golden Monkeys", "Luxury", 3, "P10", 4600, 3100, "2021-09-01", 3),
    ("PK17", "Ultimate East Africa Honeymoon", "Luxury", 12, "P06", 9800, 5900, "2022-02-14", 2),
    ("PK18", "Samburu & Laikipia Private Conservancy", "Luxury", 5, "P04", 5200, 3000, "2024-07-01", 4),
]
PKG = {p[0]: p for p in PACKAGES}

AGENTS = [
    # ID, Name, Channel, BaseCountry, CommissionPct
    ("AG00", "Direct – Website", "Direct", "Kenya", 0.00),
    ("AG01", "Direct – Nairobi Office", "Direct", "Kenya", 0.00),
    ("AG02", "WildPass Online", "OTA", "Netherlands", 0.15),
    ("AG03", "BushTrip.travel", "OTA", "United States", 0.17),
    ("AG04", "TrekHub Travel", "OTA", "United Kingdom", 0.14),
    ("AG05", "Acacia Tours GmbH", "Tour Operator", "Germany", 0.12),
    ("AG06", "Kilima Journeys Ltd", "Tour Operator", "United Kingdom", 0.12),
    ("AG07", "Horizon Adventure Co.", "Tour Operator", "United States", 0.13),
    ("AG08", "Southern Cross Expeditions", "Tour Operator", "Australia", 0.12),
    ("AG09", "Lotus Voyages", "Tour Operator", "China", 0.11),
    ("AG10", "Desert Rose Travel", "Tour Operator", "United Arab Emirates", 0.11),
    ("AG11", "Maple Leaf Wanderers", "Tour Operator", "Canada", 0.12),
    ("AG12", "BlueOak Corporate Travel", "Corporate", "United States", 0.08),
    ("AG13", "Savanna MICE Solutions", "Corporate", "Kenya", 0.07),
]
AGT = {a[0]: a for a in AGENTS}

# Country, Continent, SalesRegion, weight
COUNTRIES = [
    ("United States", "North America", "Americas", 22),
    ("Canada", "North America", "Americas", 5),
    ("Brazil", "South America", "Americas", 3),
    ("United Kingdom", "Europe", "Europe", 14),
    ("Germany", "Europe", "Europe", 9),
    ("France", "Europe", "Europe", 6),
    ("Netherlands", "Europe", "Europe", 4),
    ("Italy", "Europe", "Europe", 4),
    ("Spain", "Europe", "Europe", 3),
    ("Australia", "Oceania", "Asia-Pacific", 6),
    ("China", "Asia", "Asia-Pacific", 5),
    ("India", "Asia", "Asia-Pacific", 4),
    ("Japan", "Asia", "Asia-Pacific", 2),
    ("United Arab Emirates", "Asia", "Middle East & Africa", 3),
    ("South Africa", "Africa", "Middle East & Africa", 3),
    ("Kenya", "Africa", "Middle East & Africa", 5),
    ("Nigeria", "Africa", "Middle East & Africa", 2),
]
REGION_OF = {c[0]: c[2] for c in COUNTRIES}
MANAGERS = {
    "Americas": ("Grace Njeri", "grace.njeri@twigatrails.example"),
    "Europe": ("Daniel Otieno", "daniel.otieno@twigatrails.example"),
    "Asia-Pacific": ("Amina Wanjiru", "amina.wanjiru@twigatrails.example"),
    "Middle East & Africa": ("Brian Kiprop", "brian.kiprop@twigatrails.example"),
}

# Messy spellings that appear in the customer export
COUNTRY_VARIANTS = {
    "United States": ["USA", "U.S.A.", "United States of America", "usa"],
    "United Kingdom": ["UK", "U.K.", "Great Britain"],
    "United Arab Emirates": ["UAE"],
    "Netherlands": ["The Netherlands", "Holland"],
    "Germany": ["germany", "Deutschland"],
}

FIRST = ["James", "Olivia", "Liam", "Emma", "Noah", "Sophia", "Lucas", "Mia", "Ethan", "Ava",
         "Hannah", "Felix", "Chloé", "Mateo", "Giulia", "Pablo", "Ingrid", "Yuki", "Wei", "Priya",
         "Arjun", "Aisha", "Omar", "Thandiwe", "Sipho", "Wanjiku", "Kamau", "Chidi", "Ngozi", "Isabela",
         "Rafael", "Charlotte", "Harry", "Lena", "Jonas", "Sven", "Mei", "Hiroshi", "Fatima", "Zara"]
LAST = ["Smith", "Johnson", "Brown", "Taylor", "Wilson", "Müller", "Schmidt", "Dubois", "Martin", "Rossi",
        "García", "van Dijk", "de Vries", "Tanaka", "Wang", "Li", "Sharma", "Patel", "Al Mansoori", "Khan",
        "Nkosi", "Dlamini", "Mwangi", "Odhiambo", "Okafor", "Adeyemi", "Silva", "Santos", "O'Connor", "Walker",
        "Anderson", "Thompson", "Fischer", "Bernard", "Moreau", "Chen", "Kim", "Nakamura", "Hughes", "Clarke"]

SEGMENTS = [("Couple", 34), ("Family", 26), ("Solo", 16), ("Group", 16), ("Corporate", 8)]
AGEBANDS = ["18-24", "25-34", "35-44", "45-54", "55-64", "65+"]


def wchoice(items, weights):
    return random.choices(items, weights=weights, k=1)[0]


# --------------------------------------------------------------------------
# Customers
# --------------------------------------------------------------------------
N_CUSTOMERS = 6500
customers = []
for i in range(1, N_CUSTOMERS + 1):
    c = wchoice(COUNTRIES, [x[3] for x in COUNTRIES])
    seg = wchoice([s[0] for s in SEGMENTS], [s[1] for s in SEGMENTS])
    age = wchoice(AGEBANDS, [6, 22, 24, 20, 17, 11] if seg != "Family" else [1, 18, 42, 30, 7, 2])
    join = date(2021, 1, 1) + timedelta(days=random.randint(0, 1780))
    customers.append({
        "id": f"C{i:05d}", "first": random.choice(FIRST), "last": random.choice(LAST),
        "country": c[0], "segment": seg, "age": age, "join": join,
    })
CUST = {c["id"]: c for c in customers}
cust_by_region = defaultdict(list)
for c in customers:
    cust_by_region[REGION_OF[c["country"]]].append(c)


def messy_country(canonical):
    r = random.random()
    if canonical in COUNTRY_VARIANTS and r < 0.30:
        return random.choice(COUNTRY_VARIANTS[canonical])
    if r > 0.97:
        return f" {canonical} "  # stray whitespace
    return canonical


wb = Workbook()
ws = wb.active
ws.title = "Customers"
ws["A1"] = "CRM export — Twiga Trails Safaris — generated 2026-06-30 23:59 EAT"
ws["A1"].font = Font(bold=True)
ws.append([])
ws.append(["CustomerID", "FirstName", "LastName", "Country", "Segment", "AgeBand", "JoinDate"])
for c in customers:
    ws.append([c["id"], c["first"], c["last"], messy_country(c["country"]), c["segment"], c["age"], c["join"]])
for row in ws.iter_rows(min_row=4, min_col=7, max_col=7):
    row[0].number_format = "yyyy-mm-dd"
wb.save(DATA / "Customers.xlsx")

# --------------------------------------------------------------------------
# Bookings (fact)
# --------------------------------------------------------------------------
TRAVEL_MONTH_W = {1: 1.0, 2: 1.0, 3: 0.7, 4: 0.35, 5: 0.35, 6: 0.8,
                  7: 1.4, 8: 1.6, 9: 1.4, 10: 1.1, 11: 0.6, 12: 1.1}
PEAK = {1, 7, 8, 9, 10, 12}
PRICE_INDEX = {2023: 1.00, 2024: 1.05, 2025: 1.10, 2026: 1.15}

travel_days = []
d = date(2023, 1, 10)
while d <= date(2026, 12, 31):
    growth = 1.16 ** ((d - date(2023, 1, 1)).days / 365.25)
    travel_days.append((d, TRAVEL_MONTH_W[d.month] * growth))
    d += timedelta(days=1)

N_DRAWS = 19500
drawn = random.choices([t[0] for t in travel_days], weights=[t[1] for t in travel_days], k=N_DRAWS)

bookings = []
for travel in drawn:
    year_frac = (travel - date(2023, 1, 1)).days / 365.25
    cust = random.choice(customers)
    region = REGION_OF[cust["country"]]
    seg = cust["segment"]

    # package: luxury share grows each year; new package only after launch
    weights = []
    for p in PACKAGES:
        w = p[8]
        if p[2] == "Luxury":
            w *= 1 + 0.35 * year_frac
            if region in ("Americas", "Middle East & Africa"):
                w *= 1.3
        if p[2] == "Budget" and region == "Middle East & Africa":
            w *= 1.6
        weights.append(w)
    pk = wchoice(PACKAGES, weights)

    lead_mean = {"Budget": 35, "Mid-Range": 70, "Luxury": 130}[pk[2]]
    lead = max(3, int(random.gammavariate(2.2, lead_mean / 2.2)))
    booked = travel - timedelta(days=lead)
    if booked < date(2023, 1, 1) or booked > EXTRACT_DATE:
        continue
    if booked < date.fromisoformat(pk[7]):
        continue

    # channel
    if seg == "Corporate" and random.random() < 0.6:
        agent = random.choice(["AG12", "AG13"])
    else:
        ch = wchoice(["Direct", "OTA", "Tour Operator"], [32 + 4 * year_frac, 30, 30])
        if ch == "Direct":
            agent = wchoice(["AG00", "AG01"], [5, 1])
        elif ch == "OTA":
            agent = random.choice(["AG02", "AG03", "AG04"])
        else:
            local = [a[0] for a in AGENTS if a[2] == "Tour Operator" and REGION_OF.get(a[3]) == region]
            agent = random.choice(local) if local and random.random() < 0.7 else random.choice(
                [a[0] for a in AGENTS if a[2] == "Tour Operator"])

    adults, children = {
        "Solo": (1, 0),
        "Couple": (2, 0),
        "Family": (2, random.randint(1, 3)),
        "Group": (random.randint(4, 9), 0),
        "Corporate": (random.randint(3, 12), 0),
    }[seg]

    price = pk[5] * PRICE_INDEX[travel.year] * (1.15 if travel.month in PEAK else 1.0)
    price = int(round(price / 5.0) * 5)
    discount = wchoice([0.0, 0.05, 0.10, 0.15], [60, 20, 14, 6])
    if seg in ("Group", "Corporate") and discount == 0 and random.random() < 0.5:
        discount = 0.10

    p_cancel = 0.06 + (0.08 if AGT[agent][2] == "OTA" else 0) + (0.02 if pk[2] == "Budget" else 0) \
        + (0.03 if lead > 120 else 0)
    if random.random() < p_cancel:
        status = "Cancelled"
    elif travel + timedelta(days=pk[3]) <= EXTRACT_DATE:
        status = "Completed"
    else:
        status = "Confirmed"

    payment = wchoice(["Card", "Bank Transfer", "M-Pesa", "PayPal"],
                      [45, 30, 10 if region != "Middle East & Africa" else 45, 15])

    bookings.append({
        "booked": booked, "travel": travel, "cust": cust["id"], "pkg": pk[0], "agent": agent,
        "adults": adults, "children": children, "price": price, "discount": discount,
        "status": status, "payment": payment,
    })

bookings.sort(key=lambda b: (b["booked"], b["cust"]))
seq = defaultdict(int)
for b in bookings:
    y = b["booked"].year
    seq[y] += 1
    b["id"] = f"BK-{y}-{seq[y]:05d}"


def messy_status(s):
    r = random.random()
    if r < 0.03:
        return s.lower()
    if r < 0.05:
        return s.upper()
    if r < 0.08:
        return s + " "
    if s == "Cancelled" and r < 0.35:
        return "Canceled"
    return s


BK_HEADER = ["BookingID", "BookingDate", "TravelStartDate", "CustomerID", "PackageID", "AgentID",
             "Adults", "Children", "UnitPriceUSD", "DiscountPct", "Status", "PaymentMethod"]

raw_rows_by_file = defaultdict(list)
for b in bookings:
    y = b["booked"].year
    agent_out = "" if (b["agent"] == "AG00" and y == 2023) else b["agent"]  # legacy web system
    disc_out = b["discount"]
    if random.random() < 0.03:  # blank = "no discount" in the source system
        b["discount"] = 0.0
        disc_out = ""
    row = [b["id"], b["booked"].isoformat(), b["travel"].isoformat(), b["cust"], b["pkg"], agent_out,
           b["adults"], b["children"], b["price"], disc_out, messy_status(b["status"]), b["payment"]]
    key = "2026_H1" if y == 2026 else str(y)
    raw_rows_by_file[key].append(row)

# accidental double-export in 2024
dupes = random.sample(raw_rows_by_file["2024"], 37)
raw_rows_by_file["2024"].extend(dupes)
raw_rows_by_file["2024"].sort(key=lambda r: r[0])

for key, rows in raw_rows_by_file.items():
    target = DATA / "_later" if key == "2026_H1" else DATA / "Bookings"
    write_csv(target / f"Bookings_{key}.csv", BK_HEADER, rows)

# --------------------------------------------------------------------------
# Reviews (only for completed trips in the starting files)
# --------------------------------------------------------------------------
TEXTS = {
    5: ["Unforgettable — saw the river crossing!", "Guide was exceptional, every detail handled.",
        "Best holiday of our lives.", "Flawless from airport pickup to farewell."],
    4: ["Great sightings, lodge food could improve.", "Very good trip, long drives though.",
        "Lovely camp, a little pricey.", "Guide knew every bird by name."],
    3: ["Okay overall, vehicle was cramped.", "Wildlife good, communication before trip poor.",
        "Too many vehicles at sightings."],
    2: ["Delayed pickup and a flat tyre.", "Accommodation not as advertised."],
    1: ["Very disappointed, requested refund.", "Poor organisation from start to finish."],
}
reviews = []
rid = 0
for b in bookings:
    if b["status"] != "Completed" or b["booked"] > MAIN_END:
        continue
    if random.random() > 0.55:
        continue
    pk = PKG[b["pkg"]]
    mean = {"Budget": 3.8, "Mid-Range": 4.25, "Luxury": 4.6}[pk[2]]
    if b["travel"].month == 8:
        mean -= 0.25  # peak-season crowding
    rating = max(1, min(5, round(random.gauss(mean, 0.75))))
    nps = {5: (9, 10), 4: (7, 9), 3: (5, 7), 2: (3, 6), 1: (0, 4)}[rating]
    rdate = b["travel"] + timedelta(days=pk[3] + random.randint(1, 20))
    if rdate > EXTRACT_DATE:
        continue
    rid += 1
    reviews.append((f"RV{rid:05d}", b["id"], rdate.isoformat(), rating, random.randint(*nps),
                    random.choice(TEXTS[rating])))
write_csv(DATA / "Reviews.csv", ["ReviewID", "BookingID", "ReviewDate", "Rating", "NPSScore", "ReviewText"], reviews)

# --------------------------------------------------------------------------
# Small dimension files
# --------------------------------------------------------------------------
write_csv(DATA / "Parks.csv", ["ParkID", "ParkName", "Country", "Latitude", "Longitude", "Ecosystem",
                               "ParkFeeUSDPerDay"], PARKS)
write_csv(DATA / "Packages.csv", ["PackageID", "PackageName", "Category", "DurationDays", "PrimaryParkID",
                                  "BasePriceUSD", "CostPerPaxUSD", "LaunchDate"], [p[:8] for p in PACKAGES])
write_csv(DATA / "Agents.csv", ["AgentID", "AgentName", "Channel", "BaseCountry", "CommissionPct"], AGENTS)
write_csv(DATA / "Regions.csv", ["Country", "Continent", "SalesRegion", "RegionalManager", "ManagerEmail"],
          [(c[0], c[1], c[2], *MANAGERS[c[2]]) for c in COUNTRIES])

# --------------------------------------------------------------------------
# Answer key — computed from the *cleaned* bookings
# --------------------------------------------------------------------------
def net_amount(b):
    return (b["adults"] + 0.5 * b["children"]) * b["price"] * (1 - b["discount"])


def summarise(rows):
    live = [b for b in rows if b["status"] != "Cancelled"]
    rev = sum(net_amount(b) for b in live)
    cost = sum((b["adults"] + b["children"]) * PKG[b["pkg"]][6] for b in live)
    comm = sum(net_amount(b) * AGT[b["agent"]][4] for b in live)
    gp = rev - cost - comm
    return {
        "bookings": len(rows),
        "cancelled": len(rows) - len(live),
        "cancellation_rate": round((len(rows) - len(live)) / len(rows), 4),
        "net_revenue": round(rev, 2),
        "cost": round(cost, 2),
        "commission": round(comm, 2),
        "gross_profit": round(gp, 2),
        "gross_margin": round(gp / rev, 4),
        "travellers": sum(b["adults"] + b["children"] for b in live),
        "avg_booking_value": round(rev / len(live), 2),
    }


main = [b for b in bookings if b["booked"] <= MAIN_END]
by_year = {y: summarise([b for b in main if b["booked"].year == y]) for y in (2023, 2024, 2025)}
for y in (2024, 2025):
    by_year[y]["revenue_yoy"] = round(by_year[y]["net_revenue"] / by_year[y - 1]["net_revenue"] - 1, 4)

rv_by_year = defaultdict(list)
bk_index = {b["id"]: b for b in bookings}
for r in reviews:
    rv_by_year[bk_index[r[1]]["booked"].year].append(r)
for y, rs in rv_by_year.items():
    if y in by_year:
        by_year[y]["reviews"] = len(rs)
        by_year[y]["avg_rating"] = round(sum(r[3] for r in rs) / len(rs), 2)
        prom = sum(1 for r in rs if r[4] >= 9)
        det = sum(1 for r in rs if r[4] <= 6)
        by_year[y]["nps"] = round(100 * (prom - det) / len(rs), 1)

b25 = [b for b in main if b["booked"].year == 2025 and b["status"] != "Cancelled"]


def group_rev(rows, keyfn):
    acc = defaultdict(float)
    for b in rows:
        acc[keyfn(b)] += net_amount(b)
    return {k: round(v, 2) for k, v in sorted(acc.items(), key=lambda kv: -kv[1])}


travel_month_2025 = group_rev([b for b in main if b["travel"].year == 2025 and b["status"] != "Cancelled"],
                              lambda b: b["travel"].month)
booking_month_2025 = group_rev(b25, lambda b: b["booked"].month)

cancel_by_channel = {}
for ch in ("Direct", "OTA", "Tour Operator", "Corporate"):
    rows = [b for b in main if AGT[b["agent"]][2] == ch]
    cancel_by_channel[ch] = round(sum(1 for b in rows if b["status"] == "Cancelled") / len(rows), 4)

# Targets: monthly x category, booking-date basis
actual_mc = defaultdict(float)
for b in bookings:
    if b["status"] != "Cancelled":
        actual_mc[(b["booked"].year, b["booked"].month, PKG[b["pkg"]][2])] += net_amount(b)
targets = []
for y in (2023, 2024, 2025, 2026):
    for m in range(1, 13):
        for cat in ("Budget", "Mid-Range", "Luxury"):
            if y < 2026:
                base = actual_mc[(y, m, cat)] * random.uniform(0.92, 1.12)
            else:
                base = actual_mc[(2025, m, cat)] * 1.14
            targets.append((date(y, m, 1).isoformat(), cat, int(round(base / 1000.0) * 1000)))
write_csv(DATA / "Targets.csv", ["MonthStart", "Category", "TargetRevenueUSD"], targets)
target_2025 = sum(t[2] for t in targets if t[0].startswith("2025"))

h1_2026 = [b for b in bookings if b["booked"].year == 2026]
raw_counts = {k: len(v) for k, v in raw_rows_by_file.items()}

answer = {
    "seed": SEED,
    "row_counts_raw": raw_counts,
    "row_counts_clean": {"2023": raw_counts["2023"], "2024": raw_counts["2024"] - 37,
                         "2025": raw_counts["2025"], "2026_H1": raw_counts["2026_H1"]},
    "duplicates_removed_2024": 37,
    "blank_agent_rows_2023": sum(1 for b in main if b["booked"].year == 2023 and b["agent"] == "AG00"),
    "customers": N_CUSTOMERS,
    "distinct_country_spellings_raw": None,  # filled below
    "distinct_countries_clean": len(COUNTRIES),
    "reviews": len(reviews),
    "by_booking_year": by_year,
    "all_three_years": summarise(main),
    "revenue_2025_by_category": group_rev(b25, lambda b: PKG[b["pkg"]][2]),
    "revenue_2025_by_channel": group_rev(b25, lambda b: AGT[b["agent"]][2]),
    "revenue_2025_by_sales_region": group_rev(b25, lambda b: REGION_OF[CUST[b["cust"]]["country"]]),
    "top5_packages_2025": dict(list(group_rev(b25, lambda b: PKG[b["pkg"]][1]).items())[:5]),
    "revenue_2025_by_booking_month": dict(sorted(booking_month_2025.items())),
    "revenue_2025_by_travel_month": dict(sorted(travel_month_2025.items())),
    "cancellation_rate_by_channel": cancel_by_channel,
    "target_2025": target_2025,
    "after_2026_refresh": {"bookings_total": len(bookings),
                           "h1_2026": summarise(h1_2026)},
}

# count raw spellings exactly as written to the workbook
from openpyxl import load_workbook  # noqa: E402
raw_ws = load_workbook(DATA / "Customers.xlsx").active
answer["distinct_country_spellings_raw"] = len({r[3].value for r in raw_ws.iter_rows(min_row=4)})

(ROOT / "answer_key.json").write_text(json.dumps(answer, indent=2, ensure_ascii=False))
print(json.dumps(answer, indent=2, ensure_ascii=False))
